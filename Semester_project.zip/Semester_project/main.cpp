#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	int default_workingHours=25;
	string employee;
	int attendance,deduction,absence,choice;
	float salary,benefit;
	
	cout<<"Are you an employer or an employee?"<<endl;
	cout<<"1. Employer"<<endl;
	cout<<"2. Employee"<<endl;
	cout<<"Enter 1,2."<<endl;
	cin>>choice;
	
	if(choice==1){
		cout<<"Enter your name"<<endl;
		cin>>employee;
		cout<<"Sir / Ma'am, " <<employee<< " your salary is "<<"$"<<15*1000<<"."<< "Thank You.";
			
	}
	
	    else{
		
	    	cout<<"Enter your name: "<<endl;
	    	cin>>employee;
	    	cout<<"Enter the number of hours you worked out of the 25 hours"<<endl;
	    	cin>>attendance;
	    	
	if(attendance==default_workingHours){
		salary=attendance*150.00;
		benefit=salary*10/100;
		cout<<employee << " was puntual for the month hence there will be no deduction. "<<"Your salary is "<< "$"<< salary <<endl;
		cout<<"Your disposable income is "<<"$"<<salary+benefit<<"."<< "Thank You";
	}
	
	 
	    else if(attendance<default_workingHours){
	    	absence=default_workingHours,attendance;
	    	salary=attendance*150.00;
	    	deduction=absence*150.00;
	    	cout<<employee <<" was absent for " <<absence<< " number of hours, hence, "<< "$" <<deduction<< " will be deducted from your monthly salary"<<endl;
	    	cout<<"Your monthly salary is: "<<"$"<<salary<<"." << "You are not eligible for the 15% benefit." << " Thank You.";
	}
	    
			
	    else{
	    	cout<<"Invalid input";
		}
		}
	
	    
	    	
	return 0;
}
